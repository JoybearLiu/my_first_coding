function b_num = Betti(cell_matrix,k)
%BETTI: Betti number function    
% input the cell matrix of hyperedges, output the Betti numbers
% k is the max dimension of Betti numbers we need
betti=zeros(k,1);
%%
N=size(cell_matrix,1);
if k>N-2
    k=N-1;
end
% for alp=1:k
%     if size(cell_matrix{alp},1)==0
%         cell_matrix{alp}=zeros(1,alp);
%     end
% end
%find the number of vertices
    temp_m=zeros(N,1);
for i=1:N
    A=cell_matrix{i};
    col=size(A,2);
    if col==0
        col=col+1;
        A=zeros(1,i);
    end
    temp_m(i)=max(A(:,col));
end
d=max(temp_m);
%%
%give the boundary rank
rank_boundary=zeros(k+1,1);
rank_new=zeros(k+1,1);
for i=1:k
    if size(cell_matrix{i+1},1)==0
        rank_boundary(i)=0;
        if size(cell_matrix{i},1)==0
            rank_new(i)=0;
        else
            A_01=edge(cell_matrix{i},d);
            rank_new(i)=rank2adic(A_01);
        end
        continue
    end
    B=boundary_matrix(cell_matrix{i+1},d);%since cell from 1 other than 0
    B_01=fun_01(B,d,i-1);
    rank_boundary(i)=rank2adic(B_01);
    if i>N-1
        rank_new(i)=rank_boundary(i);
    else
        A_01=edge(cell_matrix{i},d);%the part is -1
        C_01=[A_01;B_01];
        rank_new(i)=rank2adic(C_01);
    end
end
%%
if k>N-2
    rank_boundary(k+1)=0;
    A_01=edge(cell_matrix{k+1},d);
    rank_new(k+1)=rank2adic(A_01);
else
B=boundary_matrix(cell_matrix{k+2},d);
B_01=fun_01(B,d,k);
rank_boundary(k+1)=rank2adic(B_01);
A_01=edge(cell_matrix{k+1},d);
C_01=[A_01;B_01];
rank_new(k+1)=rank2adic(C_01);
end
%%
betti_0=rank_new(1)-rank_boundary(1);
for j=1:k
    if size(cell_matrix{j+1},1)==0
        continue
    end
    betti(j,1)=rank_new(j+1)-rank_boundary(j)-rank_boundary(j+1);
end
b_num=[betti_0;betti];
end

