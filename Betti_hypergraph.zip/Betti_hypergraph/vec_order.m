function n = vec_order(vec,d)
% Given the order of a vector in the lexicographical order
% In put the vector and the dimension, output the order
s=length(vec);
A=1;
for i=1:vec(1)-1
    A=A+nchoosek(d-i,s-1);
end

for j=2:s
    for i=(vec(j-1)+1):(vec(j)-1)
        A=A+nchoosek(d-i,s-j);
    end
end
n=A;
end