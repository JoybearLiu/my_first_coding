s=[1 2 2 3 1 2];
t=[2 3 4 4 5 5];
G=graph(s,t);
plot(G);
N=neighbor_complex(G)
H=neighbor_hypergraph(G,1)
B=Betti(H,3)
