function C = neighbor_hypergraph(G,q)
%NEIGHBOR Given a graph, we obtain a neighborhood hypergraph.
% Input a graph and t parameterized the hypergraph
% Output a cell which represent a hypergraph.
A=full(adjacency(G));
[m,n]=size(A);
T=zeros(m,1);
for i=1:m
    C{i}=[];
end
for i=1:2^m-1
    i1=i;
    idx=0;
    for p=1:m
        T(p)=mod(i1,2);
        i1=fix(i1/2);
    end
    k=sum(T);
    for j=1:n
        if A(j,:)*T==k
            idx=idx+1;
        end
    end
    if idx<=q&&idx>=1
        A_index=zeros(1,k);
        t=1;
        for j=1:m
            if T(j,1)~=0
                A_index(1,t)=j;
                t=t+1;
            end
        end
        C{k}=[C{k};A_index];
    end
end













