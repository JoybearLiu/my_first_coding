function B= fun_01(M,n,r)
% input matrix index and the number of vertices, and the dimension
% output 0-1 matrix
[k,l]=size(M);
B=zeros(k,nchoosek(n,r+1));
for i=1:k
    for j=1:l
        B(i,M(i,j))=1;
    end
end
end

