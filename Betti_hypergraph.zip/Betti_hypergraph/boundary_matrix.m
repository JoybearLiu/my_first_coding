function B = boundary_matrix(M,d)
% input the set of p-simplices/p-hyperedges represented by a matrix
% input the number of vertices
% output the boundary matrix with index edges
[m,n]=size(M);
a=zeros(1,n);
B=zeros(m,n);
for i=1:m
    for j=1:n
        a=M(i,:);
        a(j)=[];
        B(i,j)=vec_order(a,d);
    end
end
end