function E = edge(N,d)
% edge matrix
% input the set of hyperedge, output the edge index matrix
[m2,n2]=size(N);
N1=zeros(m2,1);
for i=1:m2
    N1(i,1)=vec_order(N(i,:),d);
end
E=fun_01(N1,d,n2-1);
end

