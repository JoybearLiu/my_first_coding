function C = neighbor_complex(G)
%NEIGHBOR Given a graph, we obtain a neighborhood complex.
% Input a graph, output a cell which represent a complex.
A=full(adjacency(G));
[m,n]=size(A);
S=sum(A);
mm=max(S);
for i=1:mm
    C{i}=[];
end
for i=1:m
    num=sum(S(i));
    A_index=zeros(1,num);
    t=1;
    for j=1:n
        if A(i,j)~=0
            A_index(1,t)=j;
            t=t+1;
        end
    end
    C{num}=[C{num};A_index(1,:)];
end
end
