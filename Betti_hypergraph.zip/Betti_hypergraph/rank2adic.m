function brank=binrank(A)%This m file is coded by Wenzhe
%Zhang based on Cetin K. Koc's "a fast algorithm for gaussian elimination over GF(2) 
%and its implementation on the GAPP"(1991). Much faster than "rank(gf(A))" in matlab.
s=size(A);
m=s(1);
n=s(2);
mark=zeros(1,m);

for j=1:1:n
    i=find(A(:,j),1);
    if(i>=1)
        mark(1,i)=1;
        for x=1:1:n
            if((A(i,x)==1) && (x~=j))
                A(:,x)=mod((A(:,x)+A(:,j)),2);
            end
        end
    end
end

brank=sum(mark);